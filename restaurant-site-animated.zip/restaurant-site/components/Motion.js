"use client";
import { useEffect } from "react";

// Animation SIRF PEHLI BAAR chalti hai (site khulne par / pehli baar scroll karne par).
// Uske baad upar-neeche scroll karne par sab kuch jaisa hai waisa hi rehta hai, koi animation nahi.
const SEL = ".hero .chip,.hero h1,.hero p,.hero .btn,.hero-img,.steam,.sec-title,.sec-sub,.cat,.dish,.about-grid,.review,.reserve-grid>*,.news-row>*,.foot-grid>*,.footer-row";
const HERO_DELAY = { chip: 150, h1: 280, p: 410, btn: 540, "hero-img": 0, steam: 1000 };

function heroKey(el) {
  if (!el.closest(".hero")) return null;
  if (el.classList.contains("chip")) return "chip";
  if (el.classList.contains("hero-img")) return "hero-img";
  if (el.classList.contains("steam")) return "steam";
  if (el.classList.contains("btn")) return "btn";
  if (el.tagName === "H1") return "h1";
  if (el.tagName === "P") return "p";
  return null;
}

function delayFor(el) {
  const k = heroKey(el);
  if (k) return HERO_DELAY[k];
  if (el.classList.contains("sec-title")) return 0;
  if (el.classList.contains("sec-sub")) return 110;
  const parent = el.parentElement;
  if (!parent) return 0;
  const sibs = [...parent.children].filter((c) => c.matches(SEL));
  const i = Math.max(0, sibs.indexOf(el));
  const cs = getComputedStyle(parent);
  if (cs.display === "grid") {
    const cols = cs.gridTemplateColumns.split(" ").length || 1;
    return Math.min(520, (i % cols) * 80);
  }
  return Math.min(360, i * 90);
}

export default function Motion() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const root = document.documentElement;
    const isReady = () => root.classList.contains("ready");
    const seen = new WeakSet();
    const done = new WeakSet(); // jinhone pehli baar animation dikha di
    const want = new Set();     // pehli baar ke liye ruke hue (loader chal raha ho to)

    // pehli baar: poori animation
    const first = (el) => {
      done.add(el);
      el.style.setProperty("--d", `${delayFor(el)}ms`);
      el.classList.add("reveal", "in");
    };
    // jo abhi tak dikha hi nahi, use bahar wali side se aane ke liye taiyar rakho
    const hide = (el, fromTop) => {
      el.style.setProperty("--y", fromTop ? "-36px" : "36px");
      el.classList.add("reveal");
      el.classList.remove("in");
    };

    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        const el = e.target;
        const enough = e.intersectionRatio >= 0.15 || (e.isIntersecting && e.intersectionRect.height >= innerHeight * 0.25);
        if (enough) {
          if (!done.has(el)) { want.add(el); if (isReady()) first(el); }
        } else if (!e.isIntersecting) {
          const fromTop = e.boundingClientRect.top < (e.rootBounds ? e.rootBounds.top : 0);
          want.delete(el);
          if (!done.has(el)) hide(el, fromTop);
        }
      }),
      { threshold: [0, 0.05, 0.15, 0.3], rootMargin: "0px 0px -8% 0px" }
    );

    const track = (el) => {
      if (seen.has(el)) return;
      seen.add(el);
      el.classList.add("reveal");
      io.observe(el);
    };
    const scan = (node) => {
      if (node.nodeType !== 1) return;
      if (node.matches(SEL)) track(node);
      node.querySelectorAll(SEL).forEach(track);
    };

    document.querySelectorAll(SEL).forEach(track);

    // loader hatne ke baad hi hero ka intro chalta hai
    let readyMo;
    if (!isReady()) {
      readyMo = new MutationObserver(() => {
        if (isReady()) { readyMo.disconnect(); want.forEach((el) => { if (!done.has(el)) first(el); }); }
      });
      readyMo.observe(root, { attributes: true, attributeFilter: ["class"] });
    }

    // category badalne pe jo nayi dishes aati hain, unko bhi pakdo
    const mo = new MutationObserver((list) => list.forEach((m) => {
      m.addedNodes.forEach(scan);
      m.removedNodes.forEach((n) => { if (n.nodeType === 1) { io.unobserve(n); n.querySelectorAll(SEL).forEach((c) => io.unobserve(c)); } });
    }));
    mo.observe(document.body, { childList: true, subtree: true });

    return () => { io.disconnect(); mo.disconnect(); readyMo && readyMo.disconnect(); };
  }, []);
  return null;
}
