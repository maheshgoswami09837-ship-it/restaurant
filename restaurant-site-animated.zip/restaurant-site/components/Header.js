"use client";
import { useState } from "react";
import { restaurant } from "../data/restaurant";

const links = [["Home", "#top"], ["Menu", "#menu"], ["About", "#about"], ["Testimonials", "#reviews"], ["Reservation", "#reserve"], ["Contact", "#contact"]];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [a, b] = restaurant.name.toUpperCase().split(" & ");
  return (
    <header className="site-header">
      <div className="wrap header-row">
        <a href="#top" className="brand">
          <img className="logo" src="/images/logo.png" alt="" />
          <span>{b ? <>{a} <em>&</em> {b}</> : a}</span>
        </a>
        <nav className={`nav ${open ? "nav-open" : ""}`}>
          {links.map(([n, h]) => <a key={n} href={h} onClick={() => setOpen(false)}>{n}</a>)}
        </nav>
        <a className="btn btn-red order-btn" href="#menu">Order Now →</a>
        <button className="burger" aria-label="Menu" onClick={() => setOpen(!open)}><span /><span /><span /></button>
      </div>
    </header>
  );
}
