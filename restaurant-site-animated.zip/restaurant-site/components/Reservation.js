"use client";
import { useState } from "react";
import { waLink } from "../data/restaurant";

export default function Reservation() {
  const [f, setF] = useState({ name: "", email: "", date: "", time: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const href = waLink(`Hi! Table booking: ${f.name || "-"}, ${f.date || "-"} at ${f.time || "-"}. Email: ${f.email || "-"}`);
  return (
    <section id="reserve" className="reserve">
      <div className="wrap reserve-grid">
        <div>
          <h2>Reserve Your <em>Table</em></h2>
          <p>Book a table for a memorable dining experience.</p>
          <a className="btn btn-red" href="#rform">Book Now →</a>
        </div>
        <div id="rform" className="rform">
          <input placeholder="Your Name" value={f.name} onChange={set("name")} aria-label="Your name" />
          <input placeholder="Your Email" value={f.email} onChange={set("email")} aria-label="Your email" />
          <input type="date" value={f.date} onChange={set("date")} aria-label="Date" />
          <input type="time" value={f.time} onChange={set("time")} aria-label="Time" />
          <a className="btn btn-red" href={href} target="_blank" rel="noopener noreferrer">Reserve Table →</a>
        </div>
      </div>
    </section>
  );
}
