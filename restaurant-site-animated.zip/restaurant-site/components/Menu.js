"use client";
import { useState, useEffect } from "react";
import { menu, waLink } from "../data/restaurant";
import CatIcon from "./Icons";

export default function Menu() {
  const [active, setActive] = useState(-1);
  const [cart, setCart] = useState({});
  const [table, setTable] = useState("");
  useEffect(() => { setTable(new URLSearchParams(window.location.search).get("table") || ""); }, []);

  const popular = menu.flatMap((c) => c.items.filter((i) => i.popular).map((i) => ({ ...i, emoji: c.emoji })));
  const list = active < 0 ? popular : menu[active].items.map((i) => ({ ...i, emoji: menu[active].emoji }));

  const change = (it, d) => setCart((c) => {
    const qty = Math.max(0, (c[it.name]?.qty || 0) + d);
    const n = { ...c };
    if (qty) n[it.name] = { price: it.price, qty }; else delete n[it.name];
    return n;
  });
  const lines = Object.entries(cart);
  const count = lines.reduce((a, [, v]) => a + v.qty, 0);
  const total = lines.reduce((a, [, v]) => a + v.qty * v.price, 0);
  const msg = `Hi! New order${table ? ` (Table ${table})` : ""}:\n` + lines.map(([n, v]) => `${v.qty} x ${n} = ₹${v.qty * v.price}`).join("\n") + `\nTotal: ₹${total}`;

  return (
    <section id="menu" className="section">
      <div className="wrap">
        <h2 className="sec-title"><span>Our <em>Categories</em></span></h2>
        <p className="sec-sub">Choose what you love</p>
        <div className="cats">
          {menu.map((c, i) => (
            <button key={c.category} className={`cat ${i === active ? "cat-on" : ""}`} onClick={() => setActive(active === i ? -1 : i)}>
              <CatIcon name={c.category} />{c.category}
            </button>
          ))}
        </div>
        <h2 className="sec-title top-gap"><span>{active < 0 ? <>Our <em>Popular Items</em></> : <>Our <em>{menu[active].category}</em></>}</span></h2>
        <p className="sec-sub">{table ? `Table ${table} · ` : ""}Freshly made, just for you</p>
        <div className="items">
          {list.map((it) => {
            const q = cart[it.name]?.qty || 0;
            return (
              <article key={it.name} className="dish">
                <div className="dish-img">{it.image ? <img src={it.image} alt={it.name} loading="lazy" /> : <span>{it.emoji}</span>}</div>
                <div className="dish-body">
                  <h3>{it.name}</h3>
                  <p>{it.desc}</p>
                  <div className="dish-foot">
                    <span className="dish-price">₹{it.price}</span>
                    {q ? (
                      <div className="qty"><button onClick={() => change(it, -1)} aria-label="Remove one">−</button><span>{q}</span><button onClick={() => change(it, 1)} aria-label="Add one">+</button></div>
                    ) : (
                      <button className="add" onClick={() => change(it, 1)}>Add +</button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
      {count > 0 && (
        <div className="cartbar">
          <span>{count} item{count > 1 ? "s" : ""} · ₹{total}</span>
          <button className="clear" onClick={() => setCart({})}>Clear</button>
          <a className="btn btn-red" href={waLink(msg)} target="_blank" rel="noopener noreferrer">Send order</a>
        </div>
      )}
    </section>
  );
}
