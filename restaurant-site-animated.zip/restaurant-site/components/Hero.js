import { restaurant } from "../data/restaurant";
import Steam from "./Steam";
import BurgerCta from "./BurgerCta";

export default function Hero() {
  const [a, b] = restaurant.name.toUpperCase().split(" & ");
  return (
    <section id="top" className="hero">
      <div className="hero-bg" style={{ backgroundImage: `url(${restaurant.heroImage})` }} />
      <div className="wrap hero-copy">
        <span className="chip">{restaurant.tagline}</span>
        <h1>{b ? <>{a} <em>&</em> {b}</> : a}</h1>
        <p>{restaurant.intro}</p>
        <a className="btn btn-red" href="#menu">Explore Menu →</a>
      </div>
      <img className="hero-img" src={restaurant.heroImageMobile || restaurant.heroImage} alt={restaurant.name} />
      <Steam />
      <BurgerCta />
    </section>
  );
}
