import { restaurant } from "../data/restaurant";

export default function Footer() {
  const tel = `tel:${restaurant.phone.replace(/\s/g, "")}`;
  return (
    <footer id="contact" className="footer">
      <div className="wrap foot-grid">
        <div className="foot-brand">
          <img className="logo-lg" src="/images/logo.png" alt="" />
          <div><b>{restaurant.name.toUpperCase()}</b><p>{restaurant.tagline}</p></div>
        </div>
        <div><h4>Quick Links</h4><a href="#top">Home</a><a href="#menu">Menu</a><a href="#about">About</a><a href="#reserve">Reservation</a></div>
        <div><h4>Follow Us</h4>{restaurant.instagram ? <a href={restaurant.instagram} target="_blank" rel="noopener noreferrer">Instagram</a> : <p>Social links soon</p>}</div>
        <div>
          <h4>Contact Us</h4>
          <a href={tel}>{restaurant.phone}</a>
          <a href={`mailto:${restaurant.email}`}>{restaurant.email}</a>
          <p>{restaurant.address}</p>
          {restaurant.hours.map((h) => <p key={h.days}>{h.days}: {h.time}</p>)}
        </div>
      </div>
      <div className="wrap footer-row"><p>© {new Date().getFullYear()} {restaurant.name}. All Rights Reserved.</p></div>
    </footer>
  );
}
