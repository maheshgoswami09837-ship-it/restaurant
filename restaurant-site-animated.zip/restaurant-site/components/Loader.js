"use client";
import { useEffect, useState } from "react";

// 1 second ki skeleton loading: sab (photo, font) load ho jaye, phir site fade-in hoti hai.
const MIN_MS = 1000;

export default function Loader() {
  const [hide, setHide] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const start = performance.now();
    let t1, t2;
    const done = () => {
      const wait = Math.max(0, MIN_MS - (performance.now() - start));
      t1 = setTimeout(() => {
        setHide(true);
        document.documentElement.classList.add("ready");
        t2 = setTimeout(() => setGone(true), 700);
      }, wait);
    };
    if (document.readyState === "complete") done();
    else window.addEventListener("load", done, { once: true });
    return () => { window.removeEventListener("load", done); clearTimeout(t1); clearTimeout(t2); };
  }, []);

  if (gone) return null;
  return (
    <div className={`loader ${hide ? "loader-hide" : ""}`} aria-hidden="true">
      <div className="loader-in">
        <div className="sk-head"><span className="sk sk-logo" /><span className="sk sk-title" /><span className="sk sk-burger" /></div>
        <div className="sk-hero">
          <span className="sk sk-chip" /><span className="sk sk-h1" />
          <span className="sk sk-line" /><span className="sk sk-line short" />
          <span className="sk sk-btn" /><span className="sk sk-img" />
        </div>
        <div className="sk-cats">{[0, 1, 2, 3, 4, 5].map((i) => <span key={i} className="sk sk-cat" />)}</div>
        <div className="sk-items">{[0, 1, 2, 3].map((i) => <span key={i} className="sk sk-card" />)}</div>
      </div>
    </div>
  );
}
