"use client";
import { useEffect } from "react";

// Burger ke bun ka beech, photo ke andar (0 se 1, left se).
// Photo badlo to ye number bhi badlo.
const BURGER_X = 0.28;

// "Explore Menu" button ko burger ke thik upar, uske beech me rakhta hai.
// SIRF MOBILE pe (700px tak). Laptop pe button apni purani jagah (left me) hi rehta hai.
export default function BurgerCta() {
  useEffect(() => {
    const hero = document.getElementById("top");
    const img = hero && hero.querySelector(".hero-img");
    const btn = hero && hero.querySelector(".hero-copy .btn");
    if (!img || !btn) return;

    const mobile = window.matchMedia("(max-width: 700px)");
    const place = () => {
      if (!mobile.matches) { btn.style.marginLeft = ""; return; } // laptop: kuch nahi badlna
      if (!img.naturalWidth) return;
      const nw = img.naturalWidth, nh = img.naturalHeight;
      const iw = img.offsetWidth, ih = img.offsetHeight;
      const cs = getComputedStyle(img);
      let s = iw / nw, ox = 0;
      if (cs.objectFit === "cover") {
        s = Math.max(iw / nw, ih / nh);
        ox = (iw - nw * s) * (parseFloat(cs.objectPosition.split(" ")[0]) / 100);
      }
      const burgerX = img.offsetLeft + ox + BURGER_X * nw * s; // hero ke left se
      btn.style.marginLeft = "0px";
      const hr = hero.getBoundingClientRect();
      const base = btn.getBoundingClientRect().left - hr.left;  // button ki apni jagah
      const want = burgerX - btn.offsetWidth / 2;                // burger ke beech me
      const max = hero.clientWidth - btn.offsetWidth - 12;       // screen se bahar na jaye
      btn.style.marginLeft = `${Math.round(Math.min(max, Math.max(base, want)) - base)}px`;
    };

    const ro = new ResizeObserver(place);
    ro.observe(hero); ro.observe(img); ro.observe(btn);
    const onLoad = () => place();
    if (img.complete) place(); else img.addEventListener("load", onLoad, { once: true });
    window.addEventListener("resize", place);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(place);

    return () => { ro.disconnect(); img.removeEventListener("load", onLoad); window.removeEventListener("resize", place); btn.style.marginLeft = ""; };
  }, []);

  return null;
}
