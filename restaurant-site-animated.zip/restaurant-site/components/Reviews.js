import { reviews, restaurant } from "../data/restaurant";

export default function Reviews() {
  return (
    <section id="reviews" className="section">
      <div className="wrap">
        <h2 className="sec-title"><span>What Our <em>Customers</em> Say</span></h2>
        <p className="sec-sub">Real people. Real reviews.</p>
        <div className="reviews-grid">
          {reviews.map((r) => (
            <blockquote key={r.name} className="review">
              <span className="avatar">{r.name[0]}</span>
              <div>
                <p className="review-text">“{r.text}”</p>
                <footer>— {r.name}</footer>
                <p className="stars" aria-label={`${r.stars} out of 5 stars`}>{"★".repeat(r.stars)}</p>
              </div>
            </blockquote>
          ))}
        </div>
        {restaurant.sampleNote ? <p className="sample">Sample reviews for demo</p> : null}
      </div>
    </section>
  );
}
