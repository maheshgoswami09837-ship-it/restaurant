import { about, restaurant } from "../data/restaurant";

export default function About() {
  return (
    <div id="about">
      <div className="about-intro">
        <p className="about-kicker">About Our Restaurant</p>
        <h3>Where every meal feels special</h3>
        <p className="about-sub">Know the people &amp; passion behind your plate</p>
      </div>
    <section className="about">
      <div className="about-grid">
        <div className="about-media">{about.image && <img className="about-img" src={about.image} alt="Our restaurant" loading="lazy" />}</div>
        <div className="about-text">
          <h2 className="about-title">About <em>{restaurant.name}</em></h2>
          <p>{about.text}</p>
          <ul>{about.points.map((p) => <li key={p}>✔ {p}</li>)}</ul>
          <a className="btn btn-outline" href="#contact">Learn More →</a>
        </div>
      </div>
    </section>
    </div>
  );
}
