const P = {
  Burgers: ["M4 11a8 6 0 0 1 16 0H4z", "M3 14.5c2 1.5 3 1.5 4.5 0s3 1.5 4.5 0 3 1.5 4.5 0 2.5.8 4.5 0", "M4 17.5h16", "M5 20.5h14a1 1 0 0 0 1-1v-2H4v2a1 1 0 0 0 1 1z"],
  Pizzas: ["M12 21 3.5 6.5a15 15 0 0 1 17 0L12 21z", "M9 10h.01M14.5 11h.01M12 15h.01"],
  Drinks: ["M7 8h10l-1.2 12H8.2L7 8z", "M6 8h12", "M13 8l2-5h3"],
  Desserts: ["M3 19h18", "M4 19v-6l8-5 8 5v6", "M4 13h16"],
  Fries: ["M6 10h12l-1.5 10h-9L6 10z", "M8.5 10V5M12 10V3.5M15.5 10V5"],
  More: ["M3 18h18", "M5 18a7 7 0 0 1 14 0", "M12 11V9M10.5 9h3"],
};

export default function CatIcon({ name }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {(P[name] || P.More).map((d) => <path key={d} d={d} />)}
    </svg>
  );
}
