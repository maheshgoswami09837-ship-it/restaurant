"use client";
import { useEffect, useRef } from "react";

// Coffee cup ke rim ka point, photo ke andar (0 se 1 ke beech).
// Photo badlo to ye numbers bhi badlo: x = left se, y = upar se.
const CUP = { x: 0.75, y: 0.49 };

// Coffee ka fog / steam: halka sa upar uthta, hilta aur ghulta hua.
export default function Steam() {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const hero = canvas.parentElement;
    const img = hero.querySelector(".hero-img");
    const ctx = canvas.getContext("2d");
    if (!img || !ctx) return;

    const puffs = [];
    let W = 0, H = 0, ex = 0, ey = 0, u = 1;
    let raf = 0, last = 0, spawn = 0, inView = true, tabOn = true;

    // photo screen par kahan aur kitni badi dikh rahi hai, usse cup ki jagah nikalo
    const measure = () => {
      if (!img.naturalWidth) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = hero.clientWidth; H = hero.clientHeight;
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const nw = img.naturalWidth, nh = img.naturalHeight;
      const iw = img.offsetWidth, ih = img.offsetHeight;
      const cs = getComputedStyle(img);
      let s = iw / nw, ox = 0, oy = 0;
      if (cs.objectFit === "cover") {
        s = Math.max(iw / nw, ih / nh);
        const [px, py] = cs.objectPosition.split(" ").map((v) => parseFloat(v) / 100);
        ox = (iw - nw * s) * px; oy = (ih - nh * s) * py;
      }
      ex = img.offsetLeft + ox + CUP.x * nw * s;
      ey = img.offsetTop + oy + CUP.y * nh * s;
      u = (nw * s) / 1080;
    };

    // do tarah ke puff: bade naram baadal + patli tez lahrati lakeeren
    const spawnPuff = () => {
      const wisp = Math.random() < 0.4;
      puffs.push({
        x: ex + (Math.random() - 0.5) * 54 * u,
        y: ey,
        vy: (wisp ? 40 + Math.random() * 26 : 26 + Math.random() * 20) * u,
        r: (wisp ? 5 + Math.random() * 4 : 12 + Math.random() * 8) * u,
        grow: wisp ? 3.2 + Math.random() * 1.4 : 2.8 + Math.random() * 1.2,
        life: wisp ? 3.2 + Math.random() * 1.6 : 4.8 + Math.random() * 2,
        age: 0,
        amp: (wisp ? 18 + Math.random() * 22 : 10 + Math.random() * 16) * u,
        freq: wisp ? 0.9 + Math.random() * 0.8 : 0.45 + Math.random() * 0.5,
        ph: Math.random() * 6.28,
        wind: (2 + Math.random() * 10) * u,
        peak: wisp ? 0.16 + Math.random() * 0.12 : 0.1 + Math.random() * 0.1,
        stretch: wisp ? 2.2 : 1.5,
      });
    };

    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016);
      last = now;
      spawn += dt;
      const every = W < 700 ? 0.12 : 0.07;
      while (spawn > every) { spawn -= every; spawnPuff(); }
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = "lighter";
      for (let i = puffs.length - 1; i >= 0; i--) {
        const p = puffs[i];
        p.age += dt;
        const t = p.age / p.life;
        if (t >= 1) { puffs.splice(i, 1); continue; }
        const x = p.x + Math.sin(p.age * p.freq * 2 + p.ph) * p.amp * (0.3 + t) + p.wind * p.age;
        const y = p.y - p.vy * p.age;
        const r = p.r * (1 + (p.grow - 1) * t);
        const a = p.peak * (t < 0.2 ? t / 0.2 : Math.pow(1 - (t - 0.2) / 0.8, 1.4));
        ctx.save();
        ctx.translate(x, y);
        ctx.scale(1, p.stretch);
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r);
        g.addColorStop(0, `rgba(255,236,218,${a})`);
        g.addColorStop(0.5, `rgba(255,226,200,${a * 0.45})`);
        g.addColorStop(1, "rgba(255,226,200,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, 6.2832);
        ctx.fill();
        ctx.restore();
      }
      raf = requestAnimationFrame(loop);
    };

    const start = () => { if (!raf && inView && tabOn && W) { last = performance.now(); raf = requestAnimationFrame(loop); } };
    const stop = () => { cancelAnimationFrame(raf); raf = 0; };

    // screen se bahar ya tab chhupa ho to band, battery bachti hai
    const io = new IntersectionObserver(([e]) => { inView = e.isIntersecting; inView ? start() : stop(); });
    io.observe(hero);
    const onVis = () => { tabOn = !document.hidden; tabOn ? start() : stop(); };
    document.addEventListener("visibilitychange", onVis);
    const ro = new ResizeObserver(() => { measure(); start(); });
    ro.observe(hero); ro.observe(img);
    const onLoad = () => { measure(); start(); };
    if (img.complete) onLoad(); else img.addEventListener("load", onLoad, { once: true });

    return () => { stop(); io.disconnect(); ro.disconnect(); document.removeEventListener("visibilitychange", onVis); img.removeEventListener("load", onLoad); };
  }, []);

  return <canvas ref={ref} className="steam" aria-hidden="true" />;
}
