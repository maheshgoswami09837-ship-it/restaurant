import { waLink } from "../data/restaurant";

export default function Newsletter() {
  return (
    <section className="news">
      <div className="wrap news-row">
        <div>
          <h3>Get Our Latest <em>Offers</em></h3>
          <p>Join on WhatsApp for updates, deals and new dishes.</p>
        </div>
        <a className="btn btn-red" href={waLink("Hi! Please add me to offers and updates.")} target="_blank" rel="noopener noreferrer">Join on WhatsApp →</a>
      </div>
    </section>
  );
}
