# Restaurant Website (Next.js)

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Customise
Sab content `data/restaurant.js` mein hai:
- naam, tagline, headline
- **WhatsApp number** (`whatsapp: "91XXXXXXXXXX"`), phone, email, address, hours
- menu items + prices
- gallery photos (`/public/images/` mein daalo, path likho)
- reviews (placeholder hain, real reviews se replace karo)
- Google Maps embed URL

Colours `app/globals.css` ke top mein `:root` variables mein hain.

## Deploy
GitHub pe push karo, Vercel pe import karo. Done.
