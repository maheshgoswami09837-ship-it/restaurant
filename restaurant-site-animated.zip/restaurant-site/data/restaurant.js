// SAARA CONTENT YAHIN SE BADLO. Photo: public/images/ mein daalo, path yahan likho.
export const restaurant = {
  name: "RESTAURANT NAME",
  tagline: "Good Food · Good Mood",
  headline: "RESTAURANT NAME",
  intro: "Delicious food. Refreshing drinks. A perfect place to relax.",
  whatsapp: "919999999999", // country code ke saath, bina + ke
  phone: "+91 99999 99999",
  email: "hello@yourrestaurant.com",
  address: "Main Market, Your City, India",
  instagram: "",
  hours: [
    { days: "Monday to Friday", time: "11:00 AM to 11:00 PM" },
    { days: "Saturday and Sunday", time: "10:00 AM to 12:00 AM" },
  ],
  mapEmbed: "",
  heroImage: "/images/hero-mobile.jpg", // laptop + phone dono me yahi photo
  heroImageMobile: "/images/hero-mobile.jpg", // phone (square photo)
  sampleNote: true, // demo ke liye true; real site pe false
};
export const about = {
  image: "/images/about-restaurant.jpg",
  title: "About RESTAURANT NAME",
  text: "We are more than just a restaurant. We serve happiness on a plate with the perfect blend of great food and refreshing drinks.",
  points: ["Fresh Ingredients", "Great Ambience", "Friendly Service"],
};
export const menu = [
  { category: "Burgers", emoji: "🍔", items: [
    { popular: true, name: "Classic Burger", desc: "Juicy burger with fresh veggies", price: 149, image: "/images/burger-full.jpg" },
    { name: "Double Cheese Burger", desc: "Two patties, melted cheese", price: 199, image: "/images/double-cheese-burger.jpg" },
    { name: "Veg Burger", desc: "Crispy veg patty, mayo", price: 129, image: "/images/veg-burger.jpg" },
  ]},
  { category: "Pizzas", emoji: "🍕", items: [
    { popular: true, name: "Cheese Pizza", desc: "Loaded with mozzarella cheese", price: 249, image: "/images/pizza.jpg" },
    { name: "Margherita", desc: "Classic tomato and basil", price: 199, image: "/images/margherita.jpg" },
  ]},
  { category: "Drinks", emoji: "🥤", items: [
    { popular: true, name: "Cold Coffee", desc: "Chilled & refreshing", price: 99, image: "/images/coffee.jpg" },
    { name: "Fresh Lime Soda", desc: "Sweet, salted or mixed", price: 79, image: "/images/lime-soda.jpg" },
    { name: "Mango Shake", desc: "Thick and creamy", price: 129, image: "/images/mango-shake.jpg" },
  ]},
  { category: "Desserts", emoji: "🍰", items: [
    { name: "Brownie with Ice Cream", desc: "Warm brownie, chocolate sauce", price: 149, image: "/images/brownie.jpg" },
    { name: "Choco Lava", desc: "Molten chocolate centre", price: 129, image: "/images/choco-lava.jpg" },
  ]},
  { category: "Fries", emoji: "🍟", items: [
    { popular: true, name: "French Fries", desc: "Crispy & golden", price: 89, image: "/images/fries.jpg" },
    { name: "Peri Peri Fries", desc: "Spicy, tangy, crunchy", price: 109, image: "/images/peri-peri-fries.jpg" },
  ]},
  { category: "More", emoji: "🍽️", items: [
    { name: "White Sauce Pasta", desc: "Creamy, with corn and olives", price: 189, image: "/images/pasta.jpg" },
    { name: "Paneer Tikka", desc: "Tandoor-grilled, mint chutney", price: 229, image: "/images/paneer-tikka.jpg" },
  ]},
];

// Yeh placeholder reviews hain. Real customers ke reviews se replace karo.
export const reviews = [
  { name: "Rahul S.", stars: 5, text: "Amazing food and great service! My favorite place now." },
  { name: "Priya S.", stars: 5, text: "The pizza here is just perfect!" },
  { name: "Aman V.", stars: 5, text: "Lovely ambience and delicious burgers." },
];
export const waLink = (text) => `https://wa.me/${restaurant.whatsapp}?text=${encodeURIComponent(text)}`;
