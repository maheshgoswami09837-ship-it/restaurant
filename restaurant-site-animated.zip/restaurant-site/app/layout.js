import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";
import { restaurant } from "../data/restaurant";

const display = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const body = Figtree({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata = {
  title: `${restaurant.name} | ${restaurant.tagline}`,
  description: restaurant.intro,
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#FFC21A",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js');setTimeout(function(){document.documentElement.classList.add('ready')},4000)" }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
