import Header from "../components/Header";
import Hero from "../components/Hero";
import Menu from "../components/Menu";
import About from "../components/About";
import Reviews from "../components/Reviews";
import Reservation from "../components/Reservation";
import Newsletter from "../components/Newsletter";
import Footer from "../components/Footer";
import Loader from "../components/Loader";
import Motion from "../components/Motion";

export default function Home() {
  return (
    <>
      <Loader />
      <Header />
      <main>
        <Hero />
        <Menu />
        <About />
        <Reviews />
        <Reservation />
        <Newsletter />
      </main>
      <Footer />
      <Motion />
    </>
  );
}
